"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cls } from "@/lib/utils";

const menus = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/requests", label: "Requests" },
  { href: "/admin/apps", label: "Apps" },
  { href: "/admin/users", label: "Users & Roles" },
  { href: "/admin/audit", label: "Audit Log" },
];

export default function AdminSidebar() {
  const path = usePathname();

  return (
    <aside className="w-72 shrink-0 bg-slate-950 text-slate-100">
      <div className="p-5 border-b border-white/10">
        <div className="text-lg font-semibold leading-tight">Admin Panel</div>
        <div className="text-xs text-slate-400 mt-1">Superadmin Area</div>
      </div>

      <nav className="p-3 space-y-1">
        {menus.map((m) => {
          const active = path === m.href;
          return (
            <Link
              key={m.href}
              href={m.href}
              className={cls(
                "block rounded-xl px-3 py-2.5 text-sm transition",
                "hover:bg-white/10 hover:text-white",
                active
                  ? "bg-emerald-600/20 text-emerald-200 ring-1 ring-emerald-500/30"
                  : "text-slate-300"
              )}
            >
              {m.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
