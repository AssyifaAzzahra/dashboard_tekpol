"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import AdminShell from "@/components/admin/AdminShell";
import {
  LayoutDashboard,
  ClipboardList,
  AppWindow,
  Users,
  ScrollText,
  RefreshCcw,
  ArrowRight,
} from "lucide-react";

type KPI = {
  totalAll: number;
  totalToday: number;
  totalMonth: number;
  pendingAll: number;
  approvedAll: number;
  rejectedAll: number;
};

type AuditItem = {
  id: string;
  createdAt: string;
  action: string;
  entity: string;
  entityId: string | null;
  actorEmail: string | null;
};

type KpiResponse = {
  kpi: KPI;
  pendingList: unknown[];
};

type AuditResponse = AuditItem[];

// ---------------- UI helpers (clean + minimal) ----------------

function StatCard({
  label,
  value,
  icon,
}: {
  label: string;
  value: React.ReactNode;
  icon: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-xs text-slate-600">{label}</div>
          <div className="mt-2 text-3xl font-semibold tracking-tight text-black">
            {value}
          </div>
        </div>

        <div className="shrink-0 rounded-xl border border-slate-200 bg-slate-50 p-2 text-slate-900">
          {icon}
        </div>
      </div>
    </div>
  );
}

function SectionHeader({
  title,
  subtitle,
  right,
}: {
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-2">
      <div>
        <div className="text-base font-semibold text-black">{title}</div>
        {subtitle ? (
          <div className="text-sm text-slate-600 mt-0.5">{subtitle}</div>
        ) : null}
      </div>
      {right ? <div className="shrink-0">{right}</div> : null}
    </div>
  );
}

function QuickActionCard({
  href,
  title,
  desc,
  icon,
}: {
  href: string;
  title: string;
  desc: string;
  icon: React.ReactNode;
}) {
  return (
    <a
      href={href}
      className="group rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:bg-slate-50"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-sm font-semibold text-black truncate">{title}</div>
          <div className="mt-1 text-sm text-slate-600">{desc}</div>
        </div>

        <div className="shrink-0 rounded-xl border border-slate-200 bg-white p-2 text-slate-900">
          {icon}
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between text-xs text-slate-600">
        <span>Buka</span>
        <span className="inline-flex items-center gap-1 text-slate-900">
          <span className="opacity-70 group-hover:opacity-100 transition">Open</span>
          <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
        </span>
      </div>
    </a>
  );
}

function monoCompactId(v: string) {
  // biar tabel rapi: tampilkan pendek kalau panjang
  if (v.length <= 10) return v;
  return `${v.slice(0, 6)}…${v.slice(-4)}`;
}

export default function AdminDashboardPage() {
  const [kpi, setKpi] = useState<KPI | null>(null);
  const [logs, setLogs] = useState<AuditItem[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setErr(null);

    try {
      // KPI
      const res = await fetch("/api/admin/kpi", { cache: "no-store" });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        setErr(`Gagal load KPI. Pastikan login sebagai SUPERADMIN. (${res.status}) ${text}`);
        return;
      }
      const json = (await res.json()) as KpiResponse;
      setKpi(json.kpi);

      // Audit Log
      const resLog = await fetch("/api/admin/audit", { cache: "no-store" });
      if (!resLog.ok) {
        const text = await resLog.text().catch(() => "");
        setErr(`Gagal load Audit Log. (${resLog.status}) ${text}`);
        return;
      }
      const audit = (await resLog.json()) as AuditResponse;
      setLogs(Array.isArray(audit) ? audit.slice(0, 12) : []);
    } catch {
      setErr("Terjadi error jaringan saat load dashboard.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const right = useMemo(
    () => (
      <button
        type="button"
        onClick={load}
        className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 hover:bg-slate-50 active:scale-[0.99] transition"
      >
        <RefreshCcw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
        {loading ? "Refreshing..." : "Refresh"}
      </button>
    ),
    [load, loading]
  );

  const totalAll = kpi?.totalAll ?? 0;
  const pendingAll = kpi?.pendingAll ?? 0;
  const approvedAll = kpi?.approvedAll ?? 0;
  const rejectedAll = kpi?.rejectedAll ?? 0;

  return (
    <AdminShell
      title="Admin Dashboard"
      subtitle="Ringkasan KPI & audit log terbaru"
      right={right}
    >
      {err && (
        <div className="mb-4 rounded-xl border border-rose-200 bg-rose-50 text-rose-900 px-3 py-2 text-sm">
          {err}
        </div>
      )}

      {/* KPI */}
      <SectionHeader title="KPI" subtitle="Ringkasan request (all / hari ini / bulan ini)" />
      <div className="mt-3 grid md:grid-cols-3 gap-4">
        <StatCard label="Total" value={kpi ? totalAll : loading ? "…" : "-"} icon={<LayoutDashboard className="h-5 w-5" />} />
        <StatCard label="Hari Ini" value={kpi?.totalToday ?? (loading ? "…" : "-")} icon={<ClipboardList className="h-5 w-5" />} />
        <StatCard label="Bulan Ini" value={kpi?.totalMonth ?? (loading ? "…" : "-")} icon={<ScrollText className="h-5 w-5" />} />

        <StatCard label="Pending" value={kpi ? pendingAll : loading ? "…" : "-"} icon={<ClipboardList className="h-5 w-5" />} />
        <StatCard label="Approved" value={kpi ? approvedAll : loading ? "…" : "-"} icon={<ScrollText className="h-5 w-5" />} />
        <StatCard label="Rejected" value={kpi ? rejectedAll : loading ? "…" : "-"} icon={<ScrollText className="h-5 w-5" />} />
      </div>

      {/* Quick Actions */}
      <div className="mt-8">
        <SectionHeader title="Quick Actions" subtitle="Akses cepat menu admin" />
        <div className="mt-3 grid lg:grid-cols-5 md:grid-cols-2 gap-4">
          <QuickActionCard href="/admin" title="Dashboard" desc="Ringkasan KPI" icon={<LayoutDashboard className="h-5 w-5" />} />
          <QuickActionCard href="/admin/requests" title="Requests" desc={`Kelola request (${pendingAll} pending)`} icon={<ClipboardList className="h-5 w-5" />} />
          <QuickActionCard href="/admin/apps" title="Apps" desc="CRUD aplikasi" icon={<AppWindow className="h-5 w-5" />} />
          <QuickActionCard href="/admin/users" title="Users" desc="CRUD users & roles" icon={<Users className="h-5 w-5" />} />
          <QuickActionCard href="/admin/audit" title="Audit" desc="Riwayat perubahan" icon={<ScrollText className="h-5 w-5" />} />
        </div>
      </div>

      {/* Audit Log */}
      <div className="mt-8">
        <SectionHeader
          title="Audit Log Terbaru"
          subtitle="Aktivitas perubahan data terakhir"
          right={
            <a href="/admin/audit" className="text-sm text-slate-900 hover:underline">
              Lihat semua →
            </a>
          }
        />

        <div className="mt-3 overflow-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-left">
              <tr className="text-slate-600">
                <th className="p-3 whitespace-nowrap">Waktu</th>
                <th className="p-3">Action</th>
                <th className="p-3">Entity</th>
                <th className="p-3">Entity ID</th>
                <th className="p-3">Actor</th>
              </tr>
            </thead>

            <tbody>
              {logs.map((a) => (
                <tr key={a.id} className="border-t border-slate-200 hover:bg-slate-50">
                  <td className="p-3 whitespace-nowrap text-slate-900">
                    {new Date(a.createdAt).toLocaleString()}
                  </td>
                  <td className="p-3 text-black font-medium">{a.action}</td>
                  <td className="p-3 text-black">{a.entity}</td>
                  <td className="p-3 text-slate-900 font-mono" title={a.entityId ?? ""}>
                    {a.entityId ? monoCompactId(a.entityId) : "-"}
                  </td>
                  <td className="p-3 text-slate-900">{a.actorEmail ?? "-"}</td>
                </tr>
              ))}

              {!loading && logs.length === 0 && (
                <tr>
                  <td className="p-4 text-slate-600" colSpan={5}>
                    Tidak ada log.
                  </td>
                </tr>
              )}

              {loading && (
                <tr>
                  <td className="p-4 text-slate-600" colSpan={5}>
                    Memuat data...
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="mt-2 text-xs text-slate-500">
          Menampilkan 12 log terbaru.
        </div>
      </div>
    </AdminShell>
  );
}
