"use client";

import React, { useCallback, useMemo, useRef, useState } from "react";
import AdminShell from "@/components/admin/AdminShell";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { cls } from "@/lib/utils";
import {
  Search,
  RefreshCcw,
  Plus,
  Pencil,
  Trash2,
  AppWindow,
  KeyRound,
  User2,
  Building2,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

type Category = "HO" | "REGIONAL";

type AppItem = {
  id: string;
  name: string;
  category: Category;
  username: string;
  password: string;
  description?: string | null;
};

type AppForm = {
  name: string;
  category: Category;
  username: string;
  password: string;
  description: string;
};

const emptyForm: AppForm = {
  name: "",
  category: "HO",
  username: "",
  password: "",
  description: "",
};

function parseCategory(v: string): Category {
  return v === "REGIONAL" ? "REGIONAL" : "HO";
}

function badgeCategory(cat: Category) {
  return cat === "HO"
    ? "bg-emerald-50 text-emerald-900 border-emerald-200"
    : "bg-sky-50 text-sky-900 border-sky-200";
}

function monoId(id: string) {
  return id.length > 14 ? `${id.slice(0, 8)}…${id.slice(-4)}` : id;
}

async function readErrorText(res: Response) {
  const ct = res.headers.get("content-type") || "";
  try {
    if (ct.includes("application/json")) {
      const j = await res.json();
      return JSON.stringify(j);
    }
    return await res.text();
  } catch {
    return "";
  }
}

function Panel({
  title,
  subtitle,
  right,
  children,
}: {
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-200 bg-gradient-to-b from-white to-slate-50">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="text-sm font-semibold text-black">{title}</div>
            {subtitle ? <div className="mt-0.5 text-xs text-slate-600">{subtitle}</div> : null}
          </div>
          {right ? <div className="shrink-0">{right}</div> : null}
        </div>
      </div>
      <div className="p-4">{children}</div>
    </div>
  );
}

const PAGE_SIZE = 10;

export default function AdminAppsPage() {
  const [apps, setApps] = useState<AppItem[]>([]);
  const [selected, setSelected] = useState<AppItem | null>(null);
  const [form, setForm] = useState<AppForm>(emptyForm);
  const [q, setQ] = useState("");

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [page, setPage] = useState(1);

  const load = useCallback(async () => {
    setLoading(true);
    setErr(null);
    try {
      const res = await fetch("/api/admin/apps", { cache: "no-store" });
      if (!res.ok) {
        const t = await readErrorText(res);
        setErr(`Gagal load apps. (${res.status}) ${t}`);
        return;
      }
      const data = (await res.json()) as AppItem[];
      setApps(data);
      setPage(1);
    } catch {
      setErr("Terjadi error jaringan saat load apps.");
    } finally {
      setLoading(false);
    }
  }, []);

  // initial load tanpa useEffect
  const didInit = useRef(false);
  if (!didInit.current) {
    didInit.current = true;
    void load();
  }

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return apps;
    return apps.filter((a) => {
      return (
        a.name.toLowerCase().includes(s) ||
        a.category.toLowerCase().includes(s) ||
        a.username.toLowerCase().includes(s) ||
        (a.description ?? "").toLowerCase().includes(s)
      );
    });
  }, [apps, q]);

  // pagination (client-side)
  const total = filtered.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const safePage = Math.min(Math.max(page, 1), totalPages);

  const pageApps = useMemo(() => {
    const start = (safePage - 1) * PAGE_SIZE;
    return filtered.slice(start, start + PAGE_SIZE);
  }, [filtered, safePage]);

  const pick = useCallback((a: AppItem) => {
    setSelected(a);
    setErr(null);
    setForm({
      name: a.name,
      category: a.category,
      username: a.username,
      password: a.password,
      description: a.description ?? "",
    });
  }, []);

  const clearForm = useCallback(() => {
    setSelected(null);
    setForm(emptyForm);
    setErr(null);
  }, []);

  const create = useCallback(async () => {
    setErr(null);

    const res = await fetch("/api/admin/apps", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });

    if (!res.ok) {
      const t = await readErrorText(res);
      setErr(`Gagal create app. (${res.status}) ${t}`);
      return;
    }

    clearForm();
    await load();
  }, [form, load, clearForm]);

  const update = useCallback(async () => {
    if (!selected) return;
    setErr(null);

    const id = encodeURIComponent(selected.id);
    const res = await fetch(`/api/admin/apps?id=${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });

    if (!res.ok) {
      const t = await readErrorText(res);
      setErr(`Gagal update app. (${res.status}) ${t}`);
      return;
    }

    const updated = (await res.json().catch(() => null)) as AppItem | null;
    await load();

    if (updated?.id) {
      setSelected(updated);
      setForm({
        name: updated.name,
        category: updated.category,
        username: updated.username,
        password: updated.password,
        description: updated.description ?? "",
      });
    }
  }, [selected, form, load]);

  const remove = useCallback(async () => {
    if (!selected) return;

    const ok = confirm(`Hapus app "${selected.name}"?`);
    if (!ok) return;

    setErr(null);
    const id = encodeURIComponent(selected.id);

    const res = await fetch(`/api/admin/apps?id=${id}`, { method: "DELETE" });

    if (!res.ok) {
      const t = await readErrorText(res);
      setErr(`Gagal delete app. (${res.status}) ${t}`);
      return;
    }

    clearForm();
    await load();
  }, [selected, load, clearForm]);

  return (
    <AdminShell title="Apps" subtitle="Kelola aplikasi (create/update/delete) dengan tampilan rapi + pagination">
      {err && (
        <div className="mb-4 rounded-2xl border border-rose-200 bg-rose-50 text-rose-900 px-3 py-2 text-sm">
          {err}
        </div>
      )}

      {/* Top bar */}
      <div className="mb-4 flex flex-col md:flex-row md:items-center md:justify-between gap-2">
        <div className="text-sm text-slate-600">
          Total: <span className="font-semibold text-black">{total}</span> apps
          {loading ? <span className="ml-2 text-slate-500">• loading…</span> : null}
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 hover:bg-slate-50 active:scale-[0.99] transition"
            onClick={load}
            type="button"
          >
            <RefreshCcw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </button>

          <button
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 hover:bg-slate-50 active:scale-[0.99] transition"
            onClick={clearForm}
            type="button"
          >
            <Plus className="h-4 w-4" />
            New
          </button>
        </div>
      </div>

      {/* Search */}
      <Panel
        title="Search"
        subtitle="Cari berdasarkan name / category / username / description"
        right={<div className="text-xs text-slate-600">Tips: ketik minimal 2–3 karakter</div>}
      >
        <div className="relative">
          <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <Input
            className="pl-9"
            placeholder="Cari app..."
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(1);
            }}
          />
        </div>
      </Panel>

      <div className="mt-4 grid lg:grid-cols-2 gap-4">
        {/* List */}
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 bg-gradient-to-b from-white to-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AppWindow className="h-4 w-4 text-slate-700" />
              <div className="text-sm font-semibold text-black">Daftar Apps</div>
            </div>

            <div className="text-xs text-slate-600">
              Page <span className="font-semibold text-black">{safePage}</span> / {totalPages}
            </div>
          </div>

          <div className="overflow-auto">
            <table className="w-full text-sm">
              <thead className="text-left bg-slate-50 sticky top-0 z-10">
                <tr className="text-slate-600">
                  <th className="p-3">App</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Username</th>
                </tr>
              </thead>
              <tbody>
                {pageApps.map((a) => {
                  const active = selected?.id === a.id;
                  return (
                    <tr
                      key={a.id}
                      className={cls(
                        "border-t border-slate-200 cursor-pointer transition",
                        "hover:bg-slate-50",
                        active && "bg-slate-50"
                      )}
                      onClick={() => pick(a)}
                    >
                      <td className="p-3">
                        <div className="font-medium text-slate-900 flex items-center justify-between gap-2">
                          <span className="truncate">{a.name}</span>
                          <span className="font-mono text-[11px] text-slate-500" title={a.id}>
                            {monoId(a.id)}
                          </span>
                        </div>

                        {a.description ? (
                          <div className="mt-1 text-xs text-slate-500 line-clamp-1">{a.description}</div>
                        ) : (
                          <div className="mt-1 text-xs text-slate-400 italic">No description</div>
                        )}
                      </td>

                      <td className="p-3">
                        <span
                          className={cls(
                            "inline-flex items-center rounded-full border px-2 py-0.5 text-xs",
                            badgeCategory(a.category)
                          )}
                        >
                          {a.category}
                        </span>
                      </td>

                      <td className="p-3 text-slate-800">
                        <div className="inline-flex items-center gap-2">
                          <User2 className="h-4 w-4 text-slate-500" />
                          <span className="truncate">{a.username}</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}

                {!loading && total === 0 && (
                  <tr>
                    <td colSpan={3} className="p-5 text-slate-600">
                      Tidak ada apps.
                    </td>
                  </tr>
                )}

                {loading && (
                  <tr>
                    <td colSpan={3} className="p-5 text-slate-600">
                      Memuat data...
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="px-4 py-3 border-t border-slate-200 bg-white flex items-center justify-between">
            <div className="text-xs text-slate-600">
              Menampilkan{" "}
              <span className="font-semibold text-black">
                {total === 0 ? 0 : (safePage - 1) * PAGE_SIZE + 1}–{Math.min(safePage * PAGE_SIZE, total)}
              </span>{" "}
              dari <span className="font-semibold text-black">{total}</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                className="inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition"
                disabled={safePage <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                <ChevronLeft className="h-4 w-4" />
                Prev
              </button>

              <button
                type="button"
                className="inline-flex items-center gap-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition"
                disabled={safePage >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 bg-gradient-to-b from-white to-slate-50 flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold text-black">{selected ? "Edit App" : "Create App"}</div>
              <div className="text-xs text-slate-600">
                {selected ? (
                  <>
                    ID: <span className="font-mono">{monoId(selected.id)}</span>
                  </>
                ) : (
                  "Tambahkan aplikasi baru."
                )}
              </div>
            </div>

            {selected ? (
              <span className="text-xs text-slate-700 rounded-full border border-slate-200 bg-slate-50 px-2 py-1">
                Selected
              </span>
            ) : null}
          </div>

          <div className="p-4 md:p-5 space-y-3">
            <div className="grid md:grid-cols-2 gap-2">
              <div className="relative">
                <Building2 className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <Input
                  className="pl-9"
                  placeholder="Name"
                  value={form.name}
                  onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                />
              </div>

              <select
                className="border border-slate-200 bg-white text-slate-900 rounded-xl px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-200"
                value={form.category}
                onChange={(e) => setForm((p) => ({ ...p, category: parseCategory(e.target.value) }))}
              >
                <option value="HO">HO</option>
                <option value="REGIONAL">REGIONAL</option>
              </select>
            </div>

            <div className="grid md:grid-cols-2 gap-2">
              <div className="relative">
                <User2 className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <Input
                  className="pl-9"
                  placeholder="Username"
                  value={form.username}
                  onChange={(e) => setForm((p) => ({ ...p, username: e.target.value }))}
                />
              </div>

              <div className="relative">
                <KeyRound className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <Input
                  className="pl-9"
                  placeholder="Password"
                  value={form.password}
                  onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
                />
              </div>
            </div>

            <Textarea
              placeholder="Description"
              value={form.description}
              onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
              className="min-h-[92px]"
            />

            <div className="flex flex-wrap gap-2 pt-1">
              {!selected ? (
                <button
                  className="inline-flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-900 hover:bg-emerald-100 active:scale-[0.99] transition"
                  onClick={create}
                  type="button"
                >
                  <Plus className="h-4 w-4" />
                  Create
                </button>
              ) : (
                <>
                  <button
                    className="inline-flex items-center gap-2 rounded-xl border border-sky-200 bg-sky-50 px-3 py-2 text-sm text-sky-900 hover:bg-sky-100 active:scale-[0.99] transition"
                    onClick={update}
                    type="button"
                  >
                    <Pencil className="h-4 w-4" />
                    Update
                  </button>

                  <button
                    className="inline-flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-900 hover:bg-rose-100 active:scale-[0.99] transition"
                    onClick={remove}
                    type="button"
                  >
                    <Trash2 className="h-4 w-4" />
                    Delete
                  </button>
                </>
              )}

              <button
                className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 hover:bg-slate-50 active:scale-[0.99] transition"
                onClick={clearForm}
                type="button"
              >
                Reset Form
              </button>
            </div>

            <div className="text-xs text-slate-600 pt-3 border-t border-slate-200">
              Tips: klik item di tabel untuk edit. Update/Delete menggunakan endpoint{" "}
              <span className="font-mono">/api/admin/apps?id=...</span>.
            </div>
          </div>
        </div>
      </div>
    </AdminShell>
  );
}
